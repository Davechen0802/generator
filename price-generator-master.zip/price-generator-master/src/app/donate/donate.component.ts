import { Component } from '@angular/core';

@Component({
  selector: 'app-donate',
  imports: [],
  templateUrl: './donate.component.html',
})
export class DonateComponent {

}
